<?php
/**
 * Placeholder Image Generator
 * 
 * Generates placeholder images for development and testing purposes.
 * Usage: /api/placeholder.php?width=500&height=300&text=Sample+Text
 */

// Set default parameters
$width = isset($_GET['width']) ? intval($_GET['width']) : 300;
$height = isset($_GET['height']) ? intval($_GET['height']) : 200;
$text = isset($_GET['text']) ? $_GET['text'] : 'Rolsa Technologies';
$bg_color = isset($_GET['bg']) ? $_GET['bg'] : '27ae60'; // Default green
$text_color = isset($_GET['color']) ? $_GET['text_color'] : 'FFFFFF'; // Default white

// Validate parameters
$width = max(50, min(1200, $width));   // Min 50px, max 1200px
$height = max(50, min(800, $height));  // Min 50px, max 800px

// Create a new image
$image = imagecreatetruecolor($width, $height);

// Convert hex colors to RGB
function hex2rgb($hex) {
    $hex = str_replace('#', '', $hex);
    
    if(strlen($hex) == 3) {
        $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
        $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
        $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
    } else {
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
    }
    
    return array($r, $g, $b);
}

// Apply colors
list($r, $g, $b) = hex2rgb($bg_color);
$background = imagecolorallocate($image, $r, $g, $b);
list($r, $g, $b) = hex2rgb($text_color);
$textcolor = imagecolorallocate($image, $r, $g, $b);

// Fill the background with gradient
imagefill($image, 0, 0, $background);

// Create a lighter shade of the background for patterns
$light_bg = imagecolorallocate($image, 
    min(255, $r + 40), 
    min(255, $g + 40), 
    min(255, $b + 40)
);

// Create a pattern
for ($i = 0; $i < $width; $i += 20) {
    for ($j = 0; $j < $height; $j += 20) {
        if (($i + $j) % 40 == 0) {
            imagefilledrectangle($image, $i, $j, min($i + 10, $width), min($j + 10, $height), $light_bg);
        }
    }
}

// Add border
imagerectangle($image, 0, 0, $width - 1, $height - 1, $light_bg);

// Process text
$text = wordwrap($text, 30, "\n", true);
$lines = explode("\n", $text);
$line_count = count($lines);

// Select font size based on image dimensions
$font_size = min(5, max(1, intval(min($width, $height) / 100)));

// Calculate text dimensions
$line_height = imagefontheight($font_size);
$total_height = $line_height * $line_count;

// Center the text vertically
$y = ($height - $total_height) / 2;

// Add each line of text
foreach ($lines as $line) {
    $text_width = imagefontwidth($font_size) * strlen($line);
    $x = ($width - $text_width) / 2;
    
    // Draw text with a slight shadow for better visibility
    $shadow_color = imagecolorallocate($image, max(0, $r - 50), max(0, $g - 50), max(0, $b - 50));
    imagestring($image, $font_size, $x + 1, $y + 1, $line, $shadow_color);
    imagestring($image, $font_size, $x, $y, $line, $textcolor);
    
    $y += $line_height + 5;
}

// Add Rolsa logo watermark
$watermark = "Rolsa Tech";
$watermark_size = 2;
$watermark_width = imagefontwidth($watermark_size) * strlen($watermark);
$watermark_x = $width - $watermark_width - 10;
$watermark_y = $height - imagefontheight($watermark_size) - 10;

imagestring($image, $watermark_size, $watermark_x, $watermark_y, $watermark, $textcolor);

// Output the image
header("Content-Type: image/png");
imagepng($image);

// Free memory
imagedestroy($image);
