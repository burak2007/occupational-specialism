<?php
/**
 * Configuration settings for the application
 * Contains database connection details and other global settings
 */

// Database configuration
$db_config = [
    'host'     => 'localhost',       // Database host
    'username' => 'rolsa_user',      // Database username
    'password' => 'your_secure_password',  // Database password
    'database' => 'rolsa_db'         // Database name
];

// Site configuration
$site_config = [
    'site_name'        => 'Rolsa Technologies',
    'site_description' => 'Sustainable Energy Solutions for a Greener Future',
    'site_url'         => 'https://rolsatech.com',
    'admin_email'      => 'admin@rolsatech.com',
    'support_email'    => 'support@rolsatech.com',
    'sales_email'      => 'sales@rolsatech.com'
];

// Session settings
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 1);
session_name('ROLSASESSION');

// Timezone settings
date_default_timezone_set('America/New_York');

// Error reporting (change to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define constants
define('ROOT_PATH', dirname(__DIR__));
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('IMG_PATH', ROOT_PATH . '/img');

// Booking configuration
$booking_config = [
    'min_days_ahead' => 1,    // Minimum days in advance for booking
    'max_days_ahead' => 90,   // Maximum days in advance for booking
    'max_reschedules' => 2,   // Maximum number of reschedules allowed
    'cancellation_time' => 24 // Hours before appointment that cancellation is allowed
];

// Services offered
$services = [
    'consultation' => [
        'name' => 'Energy Consultation',
        'description' => 'Free consultation to assess your energy needs',
        'duration' => 60, // in minutes
        'price' => 0.00,
    ],
    'solar' => [
        'name' => 'Solar Panel Installation',
        'description' => 'Professional installation of solar panels',
        'duration' => 480, // 8 hours
        'price' => 8999.99,
    ],
    'ev' => [
        'name' => 'EV Charging Station',
        'description' => 'Installation of electric vehicle charging station',
        'duration' => 240, // 4 hours
        'price' => 1299.99,
    ],
    'smart' => [
        'name' => 'Smart Energy Management System',
        'description' => 'Installation of home energy management system',
        'duration' => 360, // 6 hours
        'price' => 2499.99,
    ]
];

// Available appointment times
$appointment_times = [
    'morning' => 'Morning (9AM - 12PM)',
    'afternoon' => 'Afternoon (1PM - 5PM)',
    'evening' => 'Evening (6PM - 8PM)'
];

// Property types
$property_types = [
    'residential' => 'Residential',
    'commercial' => 'Commercial',
    'industrial' => 'Industrial'
];

// Booking status values
$booking_statuses = [
    'pending' => 'Pending',
    'confirmed' => 'Confirmed',
    'in_progress' => 'In Progress',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled',
    'no_show' => 'No Show'
];
