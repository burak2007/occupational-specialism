<?php
/**
 * Authentication and authorization functions
 * Handles user authentication, session management, and access control
 */

// Include database functions
require_once 'db.php';

/**
 * Check if user is logged in
 * @return bool True if user is logged in, false otherwise
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Authenticate user with email and password
 * @param string $email User email
 * @param string $password User password (plaintext)
 * @return array|false User data if authenticated, false otherwise
 */
function authenticate_user($email, $password) {
    try {
        // Get user by email
        $user = db_get_row(
            "SELECT id, name, email, password, phone, address FROM users WHERE email = ?",
            [$email],
            's'
        );
        
        // Check if user exists and password is correct
        if ($user && password_verify($password, $user['password'])) {
            // Remove password from user data before returning
            unset($user['password']);
            return $user;
        }
        
        return false;
    } catch (Exception $e) {
        error_log("Authentication error: " . $e->getMessage());
        return false;
    }
}

/**
 * Register a new user
 * @param string $name User's full name
 * @param string $email User's email
 * @param string $password User's password (plaintext)
 * @param string $phone User's phone number (optional)
 * @return int|false User ID if registered successfully, false otherwise
 */
function register_user($name, $email, $password, $phone = '') {
    try {
        // Check if email already exists
        $existing_user = db_get_var(
            "SELECT id FROM users WHERE email = ?",
            [$email],
            's'
        );
        
        if ($existing_user) {
            return false;
        }
        
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert new user
        return db_execute(
            "INSERT INTO users (name, email, password, phone, created_at) VALUES (?, ?, ?, ?, NOW())",
            [$name, $email, $hashed_password, $phone],
            'ssss'
        );
    } catch (Exception $e) {
        error_log("Registration error: " . $e->getMessage());
        return false;
    }
}

/**
 * Log user in and set session variables
 * @param array $user User data
 * @param bool $remember Whether to remember the user
 * @return bool True if login successful, false otherwise
 */
function login_user($user, $remember = false) {
    // Start or regenerate session
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    } else {
        session_regenerate_id(true);
    }
    
    // Set session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    
    if (isset($user['phone'])) {
        $_SESSION['user_phone'] = $user['phone'];
    }
    
    if (isset($user['address'])) {
        $_SESSION['user_address'] = $user['address'];
    }
    
    // Set remember-me cookie if requested
    if ($remember) {
        try {
            $token = bin2hex(random_bytes(32));
            $expires = time() + (86400 * 30); // 30 days
            
            // Store token in database
            $hashed_token = password_hash($token, PASSWORD_DEFAULT);
            
            db_execute(
                "INSERT INTO remember_tokens (user_id, token, expires) VALUES (?, ?, FROM_UNIXTIME(?))",
                [$user['id'], $hashed_token, $expires],
                'isi'
            );
            
            // Set cookies
            setcookie("remember_user", $user['id'], $expires, "/", "", true, true);
            setcookie("remember_token", $token, $expires, "/", "", true, true);
        } catch (Exception $e) {
            error_log("Remember token error: " . $e->getMessage());
            // Continue without remember-me functionality
        }
    }
    
    // Log login activity
    try {
        db_execute(
            "INSERT INTO login_activity (user_id, ip_address, user_agent) VALUES (?, ?, ?)",
            [$user['id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']],
            'iss'
        );
    } catch (Exception $e) {
        error_log("Login activity logging error: " . $e->getMessage());
        // Continue without logging
    }
    
    return true;
}

/**
 * Log user out and destroy session
 * @return void
 */
function logout_user() {
    // Destroy remember-me token if exists
    if (isset($_COOKIE['remember_user']) && isset($_COOKIE['remember_token'])) {
        try {
            db_execute(
                "DELETE FROM remember_tokens WHERE user_id = ?",
                [$_COOKIE['remember_user']],
                'i'
            );
            
            // Expire cookies
            setcookie("remember_user", "", time() - 3600, "/", "", true, true);
            setcookie("remember_token", "", time() - 3600, "/", "", true, true);
        } catch (Exception $e) {
            error_log("Logout token removal error: " . $e->getMessage());
            // Continue with logout
        }
    }
    
    // Unset all session variables
    $_SESSION = [];
    
    // Destroy the session
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

/**
 * Check if user has permission to access a resource
 * @param int $resource_id ID of the resource to check
 * @param string $resource_type Type of resource (e.g., 'booking')
 * @return bool True if user has permission, false otherwise
 */
function has_permission($resource_id, $resource_type = 'booking') {
    if (!is_logged_in()) {
        return false;
    }
    
    try {
        switch ($resource_type) {
            case 'booking':
                $owner_id = db_get_var(
                    "SELECT user_id FROM bookings WHERE id = ?",
                    [$resource_id],
                    'i'
                );
                break;
                
            // Add other resource types as needed
            
            default:
                return false;
        }
        
        // Check if current user is the owner
        return $owner_id == $_SESSION['user_id'];
    } catch (Exception $e) {
        error_log("Permission check error: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if user exists by email
 * @param string $email User email
 * @return bool True if user exists, false otherwise
 */
function user_exists($email) {
    try {
        $user_id = db_get_var(
            "SELECT id FROM users WHERE email = ?",
            [$email],
            's'
        );
        
        return !empty($user_id);
    } catch (Exception $e) {
        error_log("User existence check error: " . $e->getMessage());
        return false;
    }
}

/**
 * Update user password
 * @param int $user_id User ID
 * @param string $new_password New password (plaintext)
 * @return bool True if updated successfully, false otherwise
 */
function update_password($user_id, $new_password) {
    try {
        // Hash new password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        // Update password
        $result = db_execute(
            "UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?",
            [$hashed_password, $user_id],
            'si'
        );
        
        return $result > 0;
    } catch (Exception $e) {
        error_log("Password update error: " . $e->getMessage());
        return false;
    }
}
