<?php
// Start session
session_start();

// Page title
$pageTitle = "Why Go Green - Rolsa Technologies";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Include header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Page Banner -->
    <div class="page-banner" style="background-image: url('api/placeholder.php?width=1200&height=300&text=Why Go Green')">
        <div class="banner-content">
            <h1>Why Go Green?</h1>
            <p>The benefits of sustainable energy for you and the planet</p>
        </div>
    </div>
    
    <!-- Introduction Section -->
    <section class="section">
        <div class="container">
            <div class="intro-content text-center">
                <h2 class="section-title">The <span>Green Energy Revolution</span></h2>
                <p class="intro-text">
                    The transition to renewable energy is not just an environmental choice – it's a smart decision 
                    for your home, your finances, and our collective future. Discover why more and more homeowners 
                    and businesses are making the switch to green energy solutions.
                </p>
            </div>
        </div>
    </section>
    
    <!-- Benefits Section -->
    <section class="section light-green-bg">
        <div class="container">
            <h2 class="section-title">Key <span>Benefits</span></h2>
            <div class="benefits-grid">
                <div class="benefit-card">
                    <div class="benefit-icon">💰</div>
                    <h3>Financial Savings</h3>
                    <p>
                        Investing in renewable energy technologies like solar panels can lead to significant 
                        long-term savings on your energy bills. Many customers see a return on investment 
                        within 5-7 years, followed by decades of reduced energy costs.
                    </p>
                </div>
                <div class="benefit-card">
                    <div class="benefit-icon">🌍</div>
                    <h3>Environmental Impact</h3>
                    <p>
                        Renewable energy produces significantly fewer greenhouse gas emissions than fossil fuels. 
                        By switching to green energy, you're directly reducing your carbon footprint and 
                        contributing to a healthier planet.
                    </p>
                </div>
                <div class="benefit-card">
                    <div class="benefit-icon">🏠</div>
                    <h3>Increased Property Value</h3>
                    <p>
                        Homes equipped with solar panels and other green energy technologies can see an 
                        increase in property value. Studies show that homes with solar installations sell 
                        for 4.1% more on average.
                    </p>
                </div>
                <div class="benefit-card">
                    <div class="benefit-icon">🔋</div>
                    <h3>Energy Independence</h3>
                    <p>
                        Generating your own energy reduces your dependence on utility companies and protects 
                        you from rising energy costs. With battery storage solutions, you can even maintain 
                        power during outages.
                    </p>
                </div>
                <div class="benefit-card">
                    <div class="benefit-icon">💼</div>
                    <h3>Tax Incentives</h3>
                    <p>
                        Many governments offer tax credits, rebates, and other financial incentives for 
                        installing renewable energy systems, making the initial investment more affordable.
                    </p>
                </div>
                <div class="benefit-card">
                    <div class="benefit-icon">🔄</div>
                    <h3>Renewable & Sustainable</h3>
                    <p>
                        Unlike fossil fuels, renewable energy sources like solar and wind are infinite. 
                        By tapping into these resources, you're participating in a sustainable energy 
                        future that won't run out.
                    </p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Environmental Impact Section -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">Environmental <span>Impact</span></h2>
            <div class="impact-content">
                <div class="impact-text">
                    <h3>The Climate Crisis</h3>
                    <p>
                        Climate change is one of the most pressing challenges of our time. The burning of fossil 
                        fuels for electricity, heat, and transportation is the largest source of greenhouse gas 
                        emissions, which trap heat in the atmosphere and lead to global warming.
                    </p>
                    <p>
                        The effects of climate change are already being felt worldwide, from more frequent and 
                        severe weather events to rising sea levels and disruptions to ecosystems.
                    </p>
                    <h3>How Green Energy Helps</h3>
                    <p>
                        Renewable energy sources produce little to no greenhouse gas emissions during operation. 
                        By switching from fossil fuels to renewable energy, we can significantly reduce our 
                        collective carbon footprint.
                    </p>
                    <ul class="impact-list">
                        <li>A typical home solar panel system can offset approximately 100,000 pounds of carbon dioxide over its lifetime.</li>
                        <li>Electric vehicles powered by renewable energy can reduce transportation emissions by up to 90%.</li>
                        <li>Smart energy management systems can reduce household energy consumption by 15-30%.</li>
                    </ul>
                </div>
                <div class="impact-chart">
                    <img src="api/placeholder.php?width=500&height=400&text=Carbon Reduction Chart" alt="Carbon Reduction Chart">
                    <p class="chart-caption">Average annual CO2 reduction for homes with Rolsa green energy solutions</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Testimonials Section -->
    <section class="section green-bg">
        <div class="container">
            <h2 class="section-title light">Success <span>Stories</span></h2>
            <div class="story-slider">
                <div class="story-slide">
                    <div class="story-content">
                        <div class="story-quote">
                            <p>"Since installing solar panels, our monthly energy bill has dropped from $250 to just $30. The system paid for itself in 6 years, and now we're saving thousands each year."</p>
                        </div>
                        <div class="story-person">
                            <img src="api/placeholder.php?width=100&height=100&text=JD" alt="John Davis" class="story-photo">
                            <div class="story-info">
                                <h4>John Davis</h4>
                                <p>Homeowner, Solar Panel System</p>
                                <p>Installed 2018</p>
                            </div>
                        </div>
                    </div>
                    <div class="story-image">
                        <img src="api/placeholder.php?width=500&height=300&text=Solar Home" alt="Solar Panel Installation">
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Facts Section -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">Green Energy <span>Facts</span></h2>
            <div class="facts-grid">
                <div class="fact-card">
                    <div class="fact-number">1.8</div>
                    <div class="fact-text">Million jobs in renewable energy in the US alone</div>
                </div>
                <div class="fact-card">
                    <div class="fact-number">89%</div>
                    <div class="fact-text">Reduction in solar panel costs over the last decade</div>
                </div>
                <div class="fact-card">
                    <div class="fact-number">40%</div>
                    <div class="fact-text">Of new electricity generation capacity is from renewable sources</div>
                </div>
                <div class="fact-card">
                    <div class="fact-number">25+</div>
                    <div class="fact-text">Years of typical solar panel warranty</div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- FAQ Section -->
    <section class="section light-green-bg">
        <div class="container">
            <h2 class="section-title">Frequently Asked <span>Questions</span></h2>
            <div class="faq-container">
                <div class="faq-item">
                    <h3 class="faq-question">How much can I really save with solar panels?</h3>
                    <div class="faq-answer">
                        <p>The average homeowner can save between $10,000 and $30,000 over the lifetime of their solar panel system, depending on local electricity rates, sunlight exposure, and system size. Many customers see their investment returned within 5-7 years.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h3 class="faq-question">Do solar panels work during winter or cloudy days?</h3>
                    <div class="faq-answer">
                        <p>Yes, solar panels still generate electricity on cloudy days, though at reduced efficiency. They can even produce energy in winter, as they respond to light, not heat. Modern panels are increasingly efficient at capturing diffuse light.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h3 class="faq-question">How much does an EV charging station installation cost?</h3>
                    <div class="faq-answer">
                        <p>Home EV charging stations typically cost between $500-$2,000 for the equipment, plus installation costs of $500-$1,500 depending on your home's electrical setup. Many utility companies offer rebates that can significantly reduce these costs.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h3 class="faq-question">What tax incentives are available for green energy installations?</h3>
                    <div class="faq-answer">
                        <p>The federal government currently offers a 26% tax credit for solar installations, and many states provide additional incentives. EV charging stations and energy efficiency upgrades may also qualify for various rebates and credits. Our consultants can provide up-to-date information specific to your location.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- CTA Section -->
    <section class="section cta-section">
        <div class="container">
            <h2 class="section-title light">Ready to <span>Go Green</span>?</h2>
            <div class="text-center">
                <p class="cta-text">
                    Take the first step toward a sustainable future. Schedule a consultation with one of our experts.
                </p>
                <div class="cta-buttons">
                    <a href="booking.php" class="btn btn-light">Book a Consultation</a>
                    <a href="about.php" class="btn btn-outline">Learn About Us</a>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Include footer -->
    <?php include 'includes/footer.php'; ?>
    
    <script>
        // Simple accordion functionality for FAQs
        document.addEventListener('DOMContentLoaded', function() {
            const faqQuestions = document.querySelectorAll('.faq-question');
            
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const answer = question.nextElementSibling;
                    const isOpen = question.classList.contains('active');
                    
                    // Close all FAQs
                    faqQuestions.forEach(q => {
                        q.classList.remove('active');
                        q.nextElementSibling.style.maxHeight = null;
                    });
                    
                    // If it wasn't open before, open it
                    if (!isOpen) {
                        question.classList.add('active');
                        answer.style.maxHeight = answer.scrollHeight + 'px';
                    }
                });
            });
        });
    </script>
</body>
</html>
