<?php
// Start session
session_start();

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    // Redirect to dashboard or homepage
    header("Location: dashboard.php");
    exit;
}

// Page title
$pageTitle = "Login - Rolsa Technologies";

// Check for return URL
$return_url = isset($_GET['return']) ? htmlspecialchars($_GET['return']) : 'dashboard.php';

// Check for error or success messages
$error_msg = isset($_SESSION['login_error']) ? $_SESSION['login_error'] : '';
$success_msg = isset($_SESSION['register_success']) ? $_SESSION['register_success'] : '';

// Clear session messages
unset($_SESSION['login_error']);
unset($_SESSION['register_success']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Include header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Login Section -->
    <section class="section auth-section">
        <div class="container">
            <div class="auth-container">
                <div class="auth-form-wrapper">
                    <h2 class="section-title">User <span>Login</span></h2>
                    
                    <?php if (!empty($error_msg)): ?>
                        <div class="alert alert-danger">
                            <?php echo $error_msg; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success_msg)): ?>
                        <div class="alert alert-success">
                            <?php echo $success_msg; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form id="login-form" class="auth-form" action="api/login.php" method="post">
                        <input type="hidden" name="return_url" value="<?php echo $return_url; ?>">
                        
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" required>
                            <span class="error-message" id="email-error"></span>
                        </div>
                        
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required>
                            <span class="error-message" id="password-error"></span>
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="remember" id="remember">
                                Remember me
                            </label>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-lg">Login</button>
                        </div>
                        
                        <div class="form-footer">
                            <p>Don't have an account? <a href="register.php<?php echo !empty($return_url) ? '?return=' . urlencode($return_url) : ''; ?>" class="text-link">Register Now</a></p>
                            <p><a href="#" class="text-link forgot-password">Forgot Password?</a></p>
                        </div>
                    </form>
                </div>
                <div class="auth-info">
                    <h3>Benefits of Creating an Account</h3>
                    <ul class="checkmark-list">
                        <li>Easily schedule and manage your consultations and installations</li>
                        <li>Track the status of your bookings in real-time</li>
                        <li>Receive personalized energy-saving recommendations</li>
                        <li>Access exclusive offers and promotions</li>
                        <li>Manage your profile and communication preferences</li>
                    </ul>
                    <div class="testimonial-quote">
                        <p>"Creating an account with Rolsa made it so easy to schedule my solar panel installation and track the progress. The online dashboard is intuitive and user-friendly!"</p>
                        <p class="quote-author">- Michael Chen, Customer</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Forgot Password Modal -->
    <div id="forgot-password-modal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h3 class="modal-title">Forgot Password</h3>
            <form id="forgot-password-form" action="api/forgot-password.php" method="post">
                <div class="form-group">
                    <label for="forgot-email">Email Address</label>
                    <input type="email" id="forgot-email" name="email" required>
                    <span class="error-message" id="forgot-email-error"></span>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn">Reset Password</button>
                </div>
                <p class="help-text">We'll send you an email with instructions to reset your password.</p>
            </form>
        </div>
    </div>
    
    <!-- Include footer -->
    <?php include 'includes/footer.php'; ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Form validation
            const loginForm = document.getElementById('login-form');
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            const emailError = document.getElementById('email-error');
            const passwordError = document.getElementById('password-error');
            
            loginForm.addEventListener('submit', function(e) {
                let isValid = true;
                
                // Reset error messages
                emailError.textContent = '';
                passwordError.textContent = '';
                
                // Validate email
                if (!emailInput.value.trim()) {
                    emailError.textContent = 'Email is required';
                    isValid = false;
                } else if (!/\S+@\S+\.\S+/.test(emailInput.value)) {
                    emailError.textContent = 'Please enter a valid email address';
                    isValid = false;
                }
                
                // Validate password
                if (!passwordInput.value.trim()) {
                    passwordError.textContent = 'Password is required';
                    isValid = false;
                }
                
                if (!isValid) {
                    e.preventDefault();
                }
            });
            
            // Forgot password modal
            const forgotPasswordLink = document.querySelector('.forgot-password');
            const forgotPasswordModal = document.getElementById('forgot-password-modal');
            const closeModal = forgotPasswordModal.querySelector('.close-modal');
            
            forgotPasswordLink.addEventListener('click', function(e) {
                e.preventDefault();
                forgotPasswordModal.style.display = 'flex';
            });
            
            closeModal.addEventListener('click', function() {
                forgotPasswordModal.style.display = 'none';
            });
            
            window.addEventListener('click', function(e) {
                if (e.target === forgotPasswordModal) {
                    forgotPasswordModal.style.display = 'none';
                }
            });
            
            // Forgot password form validation
            const forgotPasswordForm = document.getElementById('forgot-password-form');
            const forgotEmailInput = document.getElementById('forgot-email');
            const forgotEmailError = document.getElementById('forgot-email-error');
            
            forgotPasswordForm.addEventListener('submit', function(e) {
                let isValid = true;
                
                // Reset error message
                forgotEmailError.textContent = '';
                
                // Validate email
                if (!forgotEmailInput.value.trim()) {
                    forgotEmailError.textContent = 'Email is required';
                    isValid = false;
                } else if (!/\S+@\S+\.\S+/.test(forgotEmailInput.value)) {
                    forgotEmailError.textContent = 'Please enter a valid email address';
                    isValid = false;
                }
                
                if (!isValid) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
