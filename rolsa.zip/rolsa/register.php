<?php
// Start session
session_start();

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    // Redirect to dashboard or homepage
    header("Location: dashboard.php");
    exit;
}

// Page title
$pageTitle = "Register - Rolsa Technologies";

// Check for return URL
$return_url = isset($_GET['return']) ? htmlspecialchars($_GET['return']) : 'dashboard.php';

// Check for error messages
$error_msg = isset($_SESSION['register_error']) ? $_SESSION['register_error'] : '';

// Clear session messages
unset($_SESSION['register_error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Include header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Registration Section -->
    <section class="section auth-section">
        <div class="container">
            <div class="auth-container">
                <div class="auth-form-wrapper">
                    <h2 class="section-title">Create <span>Account</span></h2>
                    
                    <?php if (!empty($error_msg)): ?>
                        <div class="alert alert-danger">
                            <?php echo $error_msg; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form id="register-form" class="auth-form" action="api/register.php" method="post">
                        <input type="hidden" name="return_url" value="<?php echo $return_url; ?>">
                        
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" id="name" name="name" required>
                            <span class="error-message" id="name-error"></span>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" required>
                            <span class="error-message" id="email-error"></span>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" required>
                            <span class="error-message" id="phone-error"></span>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" id="password" name="password" required>
                                <span class="error-message" id="password-error"></span>
                            </div>
                            <div class="form-group">
                                <label for="confirm-password">Confirm Password</label>
                                <input type="password" id="confirm-password" name="confirm_password" required>
                                <span class="error-message" id="confirm-password-error"></span>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="terms" id="terms" required>
                                I agree to the <a href="#" class="text-link">Terms and Conditions</a> and <a href="#" class="text-link">Privacy Policy</a>
                            </label>
                            <span class="error-message" id="terms-error"></span>
                        </div>
                        
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="newsletter" id="newsletter">
                                I would like to receive updates about new products, services, and promotions
                            </label>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" class="btn btn-lg">Create Account</button>
                        </div>
                        
                        <div class="form-footer">
                            <p>Already have an account? <a href="login.php<?php echo !empty($return_url) ? '?return=' . urlencode($return_url) : ''; ?>" class="text-link">Login</a></p>
                        </div>
                    </form>
                </div>
                <div class="auth-info">
                    <h3>Why Join Rolsa Technologies?</h3>
                    <ul class="checkmark-list">
                        <li>Get personalized recommendations for green energy solutions</li>
                        <li>Easily schedule and manage your appointments</li>
                        <li>Receive updates on your installation progress</li>
                        <li>Access exclusive offers and incentives</li>
                        <li>Stay informed about the latest in sustainable energy</li>
                    </ul>
                    <div class="info-card">
                        <h4>Data Security Promise</h4>
                        <p>Your privacy is important to us. We implement industry-standard security measures to protect your personal information. We never sell your data to third parties.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Include footer -->
    <?php include 'includes/footer.php'; ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Form validation
            const registerForm = document.getElementById('register-form');
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');
            const phoneInput = document.getElementById('phone');
            const passwordInput = document.getElementById('password');
            const confirmPasswordInput = document.getElementById('confirm-password');
            const termsCheckbox = document.getElementById('terms');
            
            const nameError = document.getElementById('name-error');
            const emailError = document.getElementById('email-error');
            const phoneError = document.getElementById('phone-error');
            const passwordError = document.getElementById('password-error');
            const confirmPasswordError = document.getElementById('confirm-password-error');
            const termsError = document.getElementById('terms-error');
            
            registerForm.addEventListener('submit', function(e) {
                let isValid = true;
                
                // Reset error messages
                nameError.textContent = '';
                emailError.textContent = '';
                phoneError.textContent = '';
                passwordError.textContent = '';
                confirmPasswordError.textContent = '';
                termsError.textContent = '';
                
                // Validate name
                if (!nameInput.value.trim()) {
                    nameError.textContent = 'Name is required';
                    isValid = false;
                } else if (nameInput.value.trim().length < 2) {
                    nameError.textContent = 'Please enter your full name';
                    isValid = false;
                }
                
                // Validate email
                if (!emailInput.value.trim()) {
                    emailError.textContent = 'Email is required';
                    isValid = false;
                } else if (!/\S+@\S+\.\S+/.test(emailInput.value)) {
                    emailError.textContent = 'Please enter a valid email address';
                    isValid = false;
                }
                
                // Validate phone
                if (!phoneInput.value.trim()) {
                    phoneError.textContent = 'Phone number is required';
                    isValid = false;
                } else if (!/^[0-9\s\(\)\-\+]{10,15}$/.test(phoneInput.value.replace(/\s/g, ''))) {
                    phoneError.textContent = 'Please enter a valid phone number';
                    isValid = false;
                }
                
                // Validate password
                if (!passwordInput.value) {
                    passwordError.textContent = 'Password is required';
                    isValid = false;
                } else if (passwordInput.value.length < 8) {
                    passwordError.textContent = 'Password must be at least 8 characters long';
                    isValid = false;
                } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(passwordInput.value)) {
                    passwordError.textContent = 'Password must contain at least one uppercase letter, one lowercase letter, and one number';
                    isValid = false;
                }
                
                // Validate confirm password
                if (!confirmPasswordInput.value) {
                    confirmPasswordError.textContent = 'Please confirm your password';
                    isValid = false;
                } else if (confirmPasswordInput.value !== passwordInput.value) {
                    confirmPasswordError.textContent = 'Passwords do not match';
                    isValid = false;
                }
                
                // Validate terms
                if (!termsCheckbox.checked) {
                    termsError.textContent = 'You must agree to the Terms and Conditions';
                    isValid = false;
                }
                
                if (!isValid) {
                    e.preventDefault();
                }
            });
            
            // Password strength meter
            const strengthMeter = document.createElement('div');
            strengthMeter.className = 'password-strength';
            strengthMeter.innerHTML = '<div class="strength-meter"></div><span class="strength-text"></span>';
            passwordInput.parentNode.insertBefore(strengthMeter, passwordError);
            
            const strengthBar = strengthMeter.querySelector('.strength-meter');
            const strengthText = strengthMeter.querySelector('.strength-text');
            
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                let strength = 0;
                
                if (password.length >= 8) strength += 1;
                if (/[A-Z]/.test(password)) strength += 1;
                if (/[a-z]/.test(password)) strength += 1;
                if (/[0-9]/.test(password)) strength += 1;
                if (/[^A-Za-z0-9]/.test(password)) strength += 1;
                
                strengthBar.className = 'strength-meter';
                
                switch (strength) {
                    case 0:
                        strengthBar.classList.add('very-weak');
                        strengthText.textContent = 'Very Weak';
                        break;
                    case 1:
                    case 2:
                        strengthBar.classList.add('weak');
                        strengthText.textContent = 'Weak';
                        break;
                    case 3:
                        strengthBar.classList.add('medium');
                        strengthText.textContent = 'Medium';
                        break;
                    case 4:
                        strengthBar.classList.add('strong');
                        strengthText.textContent = 'Strong';
                        break;
                    case 5:
                        strengthBar.classList.add('very-strong');
                        strengthText.textContent = 'Very Strong';
                        break;
                }
                
                let width = (strength / 5) * 100;
                strengthBar.style.width = width + '%';
            });
            
            // Real-time password match validation
            confirmPasswordInput.addEventListener('input', function() {
                if (this.value && this.value !== passwordInput.value) {
                    confirmPasswordError.textContent = 'Passwords do not match';
                } else {
                    confirmPasswordError.textContent = '';
                }
            });
        });
    </script>
</body>
</html>
