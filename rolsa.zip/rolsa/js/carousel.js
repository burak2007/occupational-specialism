/**
 * Image Carousel Functionality
 * Provides functionality for the homepage image carousel
 */

document.addEventListener('DOMContentLoaded', function() {
    // Carousel elements
    const carouselContainer = document.querySelector('.carousel-container');
    
    // If no carousel is present on this page, exit
    if (!carouselContainer) return;
    
    const slides = document.querySelectorAll('.carousel-slide');
    const indicators = document.querySelectorAll('.carousel-indicator');
    const prevBtn = document.querySelector('.carousel-prev');
    const nextBtn = document.querySelector('.carousel-next');
    
    // Variables
    let currentSlide = 0;
    let slideInterval;
    let isPlaying = true;
    let touchStartX = 0;
    let touchEndX = 0;
    
    // Initialize the carousel
    initCarousel();
    
    /**
     * Initialize the carousel
     */
    function initCarousel() {
        // Start automatic slideshow
        startSlideshow();
        
        // Event listeners for controls
        setupEventListeners();
        
        // Enable touch swipe on mobile
        enableTouchSwipe();
        
        // Add play/pause functionality
        addPlayPauseControl();
        
        // Ensure first slide is active
        showSlide(0);
    }
    
    /**
     * Set up event listeners for carousel controls
     */
    function setupEventListeners() {
        // Next button click
        if (nextBtn) {
            nextBtn.addEventListener('click', function() {
                resetInterval();
                nextSlide();
            });
        }
        
        // Previous button click
        if (prevBtn) {
            prevBtn.addEventListener('click', function() {
                resetInterval();
                prevSlide();
            });
        }
        
        // Indicator clicks
        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', function() {
                resetInterval();
                showSlide(index);
            });
        });
        
        // Pause on hover (optional)
        carouselContainer.addEventListener('mouseenter', function() {
            clearInterval(slideInterval);
        });
        
        carouselContainer.addEventListener('mouseleave', function() {
            if (isPlaying) {
                startSlideshow();
            }
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (isElementInViewport(carouselContainer)) {
                if (e.key === 'ArrowLeft') {
                    resetInterval();
                    prevSlide();
                } else if (e.key === 'ArrowRight') {
                    resetInterval();
                    nextSlide();
                }
            }
        });
    }
    
    /**
     * Enable touch swipe for mobile devices
     */
    function enableTouchSwipe() {
        carouselContainer.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });
        
        carouselContainer.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        }, { passive: true });
    }
    
    /**
     * Handle swipe gestures
     */
    function handleSwipe() {
        const threshold = 50; // Minimum distance to be considered a swipe
        
        if (touchEndX + threshold < touchStartX) {
            // Swipe left - show next slide
            resetInterval();
            nextSlide();
        } else if (touchEndX > touchStartX + threshold) {
            // Swipe right - show previous slide
            resetInterval();
            prevSlide();
        }
    }
    
    /**
     * Add play/pause control to the carousel
     */
    function addPlayPauseControl() {
        // Create play/pause button
        const playPauseBtn = document.createElement('button');
        playPauseBtn.className = 'carousel-playpause';
        playPauseBtn.innerHTML = '❚❚'; // Pause symbol
        playPauseBtn.setAttribute('aria-label', 'Pause slideshow');
        playPauseBtn.setAttribute('title', 'Pause slideshow');
        
        // Insert button after the indicators
        carouselContainer.appendChild(playPauseBtn);
        
        // Add event listener
        playPauseBtn.addEventListener('click', function() {
            if (isPlaying) {
                // Pause the slideshow
                clearInterval(slideInterval);
                playPauseBtn.innerHTML = '▶'; // Play symbol
                playPauseBtn.setAttribute('aria-label', 'Play slideshow');
                playPauseBtn.setAttribute('title', 'Play slideshow');
            } else {
                // Resume the slideshow
                startSlideshow();
                playPauseBtn.innerHTML = '❚❚'; // Pause symbol
                playPauseBtn.setAttribute('aria-label', 'Pause slideshow');
                playPauseBtn.setAttribute('title', 'Pause slideshow');
            }
            
            isPlaying = !isPlaying;
        });
    }
    
    /**
     * Start automatic slideshow
     */
    function startSlideshow() {
        // Clear any existing interval
        clearInterval(slideInterval);
        
        // Set new interval - change slides every 5 seconds
        slideInterval = setInterval(nextSlide, 5000);
    }
    
    /**
     * Reset interval after user interaction
     */
    function resetInterval() {
        if (isPlaying) {
            clearInterval(slideInterval);
            startSlideshow();
        }
    }
    
    /**
     * Show a specific slide by index
     * @param {number} n - slide index to show
     */
    function showSlide(n) {
        // Calculate correct slide index (handling overflow)
        currentSlide = (n + slides.length) % slides.length;
        
        // Hide all slides and remove active class from indicators
        slides.forEach(slide => slide.classList.remove('active'));
        indicators.forEach(indicator => indicator.classList.remove('active'));
        
        // Show the current slide and set active indicator
        slides[currentSlide].classList.add('active');
        if (indicators[currentSlide]) {
            indicators[currentSlide].classList.add('active');
        }
        
        // Announce slide change to screen readers
        announceSlideChange();
    }
    
    /**
     * Show the next slide
     */
    function nextSlide() {
        showSlide(currentSlide + 1);
    }
    
    /**
     * Show the previous slide
     */
    function prevSlide() {
        showSlide(currentSlide - 1);
    }
    
    /**
     * Announce slide change to screen readers for accessibility
     */
    function announceSlideChange() {
        const ariaLive = document.createElement('div');
        ariaLive.setAttribute('aria-live', 'polite');
        ariaLive.classList.add('sr-only'); // Screen reader only
        ariaLive.textContent = `Showing slide ${currentSlide + 1} of ${slides.length}`;
        
        carouselContainer.appendChild(ariaLive);
        
        // Remove after announcement
        setTimeout(() => {
            carouselContainer.removeChild(ariaLive);
        }, 1000);
    }
    
    /**
     * Check if an element is in the viewport
     * @param {HTMLElement} element - Element to check
     * @return {boolean} - True if element is in viewport
     */
    function isElementInViewport(element) {
        const rect = element.getBoundingClientRect();
        
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
});
