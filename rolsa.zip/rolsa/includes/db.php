<?php
/**
 * Database connection functions
 * This file handles database connections and provides helper functions for database operations
 */

// Include configuration file
require_once 'config.php';

/**
 * Connect to the database
 * @return mysqli Database connection
 * @throws Exception If connection fails
 */
function connect_db() {
    global $db_config;
    
    // Create connection
    $conn = new mysqli(
        $db_config['host'],
        $db_config['username'],
        $db_config['password'],
        $db_config['database']
    );
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }
    
    // Set charset to ensure proper encoding
    $conn->set_charset("utf8mb4");
    
    return $conn;
}

/**
 * Execute a SELECT query and return results as an array
 * @param string $sql SQL query string
 * @param array $params Parameters for prepared statement
 * @param string $types Types of parameters (i=int, s=string, d=double, b=blob)
 * @return array Results as associative array
 * @throws Exception If query fails
 */
function db_select($sql, $params = [], $types = '') {
    try {
        $conn = connect_db();
        $stmt = $conn->prepare($sql);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        $stmt->close();
        $conn->close();
        
        return $data;
    } catch (Exception $e) {
        throw new Exception("Database query error: " . $e->getMessage());
    }
}

/**
 * Execute an INSERT, UPDATE, or DELETE query
 * @param string $sql SQL query string
 * @param array $params Parameters for prepared statement
 * @param string $types Types of parameters (i=int, s=string, d=double, b=blob)
 * @return int|string ID of inserted row or number of affected rows
 * @throws Exception If query fails
 */
function db_execute($sql, $params = [], $types = '') {
    try {
        $conn = connect_db();
        $stmt = $conn->prepare($sql);
        
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        
        $stmt->execute();
        
        // If INSERT, return the ID of the inserted row
        if (strpos(strtoupper($sql), 'INSERT') === 0) {
            $result = $conn->insert_id;
        } else {
            // Otherwise return the number of affected rows
            $result = $stmt->affected_rows;
        }
        
        $stmt->close();
        $conn->close();
        
        return $result;
    } catch (Exception $e) {
        throw new Exception("Database query error: " . $e->getMessage());
    }
}

/**
 * Get a single row from the database
 * @param string $sql SQL query string
 * @param array $params Parameters for prepared statement
 * @param string $types Types of parameters
 * @return array|null Single row as associative array or null if not found
 * @throws Exception If query fails
 */
function db_get_row($sql, $params = [], $types = '') {
    $result = db_select($sql, $params, $types);
    return !empty($result) ? $result[0] : null;
}

/**
 * Get a single value from the database
 * @param string $sql SQL query string
 * @param array $params Parameters for prepared statement
 * @param string $types Types of parameters
 * @return mixed|null Single value or null if not found
 * @throws Exception If query fails
 */
function db_get_var($sql, $params = [], $types = '') {
    $row = db_get_row($sql, $params, $types);
    return !empty($row) ? reset($row) : null;
}

/**
 * Begin a transaction
 * @return mysqli Database connection
 * @throws Exception If beginning transaction fails
 */
function db_begin_transaction() {
    $conn = connect_db();
    if (!$conn->begin_transaction()) {
        throw new Exception("Failed to begin transaction");
    }
    return $conn;
}

/**
 * Commit a transaction
 * @param mysqli $conn Database connection
 * @throws Exception If committing transaction fails
 */
function db_commit($conn) {
    if (!$conn->commit()) {
        throw new Exception("Failed to commit transaction");
    }
    $conn->close();
}

/**
 * Rollback a transaction
 * @param mysqli $conn Database connection
 */
function db_rollback($conn) {
    $conn->rollback();
    $conn->close();
}
