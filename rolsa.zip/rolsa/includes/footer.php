<!-- Footer -->
<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-column">
                <h3>Rolsa Technologies</h3>
                <p>Providing sustainable energy solutions for a greener future.</p>
                <div class="social-links">
                    <a href="#" title="Facebook">FB</a>
                    <a href="#" title="Twitter">TW</a>
                    <a href="#" title="LinkedIn">IN</a>
                    <a href="#" title="Instagram">IG</a>
                </div>
            </div>
            <div class="footer-column">
                <h3>Products</h3>
                <ul class="footer-links">
                    <li><a href="booking.php?service=solar">Solar Panels</a></li>
                    <li><a href="booking.php?service=ev">EV Charging Stations</a></li>
                    <li><a href="booking.php?service=smart">Smart Home Systems</a></li>
                    <li><a href="booking.php?service=consultation">Energy Consultations</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Resources</h3>
                <ul class="footer-links">
                    <li><a href="why-go-green.php">Green Energy Guide</a></li>
                    <li><a href="why-go-green.php#faq">FAQ</a></li>
                    <li><a href="why-go-green.php#tax-credits">Tax Incentives</a></li>
                    <li><a href="blog.php">Energy Saving Tips</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3>Contact Us</h3>
                <ul class="footer-links">
                    <li>123 Green Street, Eco City</li>
                    <li>+1 (555) 123-4567</li>
                    <li>info@rolsatech.com</li>
                    <li>Mon-Fri: 9AM-5PM</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Rolsa Technologies. All rights reserved.</p>
            <ul class="policy-links">
                <li><a href="privacy-policy.php">Privacy Policy</a></li>
                <li><a href="terms-of-service.php">Terms of Service</a></li>
                <li><a href="sitemap.php">Sitemap</a></li>
            </ul>
        </div>
    </div>
</footer>
