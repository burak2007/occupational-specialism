<!-- Header -->
<header>
    <div class="container">
        <div class="header-content">
            <a href="index.php" class="logo">Rolsa<span>Tech</span></a>
            <div class="mobile-menu-btn">☰</div>
            <nav>
                <ul>
                    <li><a href="index.php" <?php echo ($pageTitle == "Home - Rolsa Technologies") ? 'class="active"' : ''; ?>>Home</a></li>
                    <li><a href="about.php" <?php echo ($pageTitle == "About Us - Rolsa Technologies") ? 'class="active"' : ''; ?>>About Us</a></li>
                    <li><a href="why-go-green.php" <?php echo ($pageTitle == "Why Go Green - Rolsa Technologies") ? 'class="active"' : ''; ?>>Why Go Green</a></li>
                    <li><a href="booking.php" <?php echo ($pageTitle == "Book a Consultation or Installation - Rolsa Technologies") ? 'class="active"' : ''; ?>>Book Now</a></li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li><a href="dashboard.php" <?php echo ($pageTitle == "My Dashboard - Rolsa Technologies") ? 'class="active"' : ''; ?>>My Dashboard</a></li>
                        <li><a href="logout.php" class="btn">Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="btn">Login/Register</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</header>

<!-- Mobile menu script -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
        const navMenu = document.querySelector('nav ul');
        
        mobileMenuBtn.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    });
</script>
