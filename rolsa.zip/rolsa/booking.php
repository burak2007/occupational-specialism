<?php
// Start session
session_start();

// Check if a specific service was requested
$selectedService = isset($_GET['service']) ? $_GET['service'] : '';

// Page title
$pageTitle = "Book a Consultation or Installation - Rolsa Technologies";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Include header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Page Banner -->
    <div class="page-banner" style="background-image: url('api/placeholder.php?width=1200&height=300&text=Book with Rolsa')">
        <div class="banner-content">
            <h1>Book a Consultation or Installation</h1>
            <p>Take the first step towards sustainable energy</p>
        </div>
    </div>
    
    <!-- Booking Options Section -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">Select a <span>Service</span></h2>
            <div class="booking-tabs">
                <div class="tab-headers">
                    <button class="tab-btn <?php echo ($selectedService == '' || $selectedService == 'consultation') ? 'active' : ''; ?>" data-tab="consultation">
                        Consultation
                    </button>
                    <button class="tab-btn <?php echo ($selectedService == 'solar') ? 'active' : ''; ?>" data-tab="solar">
                        Solar Panel Installation
                    </button>
                    <button class="tab-btn <?php echo ($selectedService == 'ev') ? 'active' : ''; ?>" data-tab="ev">
                        EV Charging Station
                    </button>
                    <button class="tab-btn <?php echo ($selectedService == 'smart') ? 'active' : ''; ?>" data-tab="smart">
                        Smart Energy System
                    </button>
                </div>
                <div class="tab-content">
                    <div class="tab-panel <?php echo ($selectedService == '' || $selectedService == 'consultation') ? 'active' : ''; ?>" id="consultation-panel">
                        <div class="panel-description">
                            <h3>Free Energy Consultation</h3>
                            <p>
                                Our energy experts will evaluate your home or business and recommend the best 
                                sustainable energy solutions for your needs and budget. During the consultation, we'll:
                            </p>
                            <ul>
                                <li>Assess your current energy usage and costs</li>
                                <li>Evaluate your property for solar potential</li>
                                <li>Discuss your energy goals and concerns</li>
                                <li>Present customized green energy options</li>
                                <li>Provide detailed cost estimates and savings projections</li>
                            </ul>
                            <p>
                                <strong>Duration:</strong> Approximately 60-90 minutes<br>
                                <strong>Cost:</strong> Free
                            </p>
                        </div>
                    </div>
                    <div class="tab-panel <?php echo ($selectedService == 'solar') ? 'active' : ''; ?>" id="solar-panel">
                        <div class="panel-description">
                            <h3>Solar Panel Installation</h3>
                            <p>
                                Our professional team will install high-efficiency solar panels on your property, 
                                helping you generate clean electricity and reduce your energy bills. The process includes:
                            </p>
                            <ul>
                                <li>Detailed site assessment and system design</li>
                                <li>Handling of all necessary permits and paperwork</li>
                                <li>Professional installation by certified technicians</li>
                                <li>System testing and grid connection</li>
                                <li>Complete setup of monitoring software</li>
                                <li>Final walkthrough and education on system operation</li>
                            </ul>
                            <p>
                                <strong>Installation Time:</strong> 1-3 days depending on system size<br>
                                <strong>Warranty:</strong> 25 years on panels, 10 years on installation workmanship
                            </p>
                        </div>
                    </div>
                    <div class="tab-panel <?php echo ($selectedService == 'ev') ? 'active' : ''; ?>" id="ev-panel">
                        <div class="panel-description">
                            <h3>EV Charging Station Installation</h3>
                            <p>
                                Charge your electric vehicle conveniently at home with our professional EV charging 
                                station installation service. We offer:
                            </p>
                            <ul>
                                <li>Consultation to determine the best charging solution for your needs</li>
                                <li>Professional installation by certified electricians</li>
                                <li>All necessary electrical upgrades if required</li>
                                <li>Testing and demonstration of usage</li>
                                <li>Integration with home energy management systems (optional)</li>
                            </ul>
                            <p>
                                <strong>Installation Time:</strong> 4-8 hours for standard installations<br>
                                <strong>Warranty:</strong> 3 years on equipment, 1 year on installation
                            </p>
                        </div>
                    </div>
                    <div class="tab-panel <?php echo ($selectedService == 'smart') ? 'active' : ''; ?>" id="smart-panel">
                        <div class="panel-description">
                            <h3>Smart Energy Management System</h3>
                            <p>
                                Optimize your energy usage with our intelligent home energy management systems. 
                                This service includes:
                            </p>
                            <ul>
                                <li>Evaluation of your current energy usage patterns</li>
                                <li>Installation of smart monitoring devices and sensors</li>
                                <li>Setup of energy management software and mobile app</li>
                                <li>Integration with existing smart home systems if applicable</li>
                                <li>Detailed training on system usage and optimization</li>
                            </ul>
                            <p>
                                <strong>Installation Time:</strong> 1-2 days depending on home size and complexity<br>
                                <strong>Warranty:</strong> 2 years on hardware, 1 year free software updates
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Booking Form Section -->
    <section class="section light-green-bg">
        <div class="container">
            <h2 class="section-title">Schedule Your <span>Appointment</span></h2>
            <div class="booking-container">
                <form id="booking-form" class="booking-form" action="api/booking.php" method="post">
                    <input type="hidden" id="service-type" name="service_type" value="<?php echo $selectedService == '' ? 'consultation' : $selectedService; ?>">
                    <input type="hidden" name="booking_type" id="booking-type" value="consultation">
                    
                    <div class="form-section">
                        <h3>Personal Information</h3>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="full-name">Full Name *</label>
                                <input type="text" id="full-name" name="full_name" required>
                                <span class="error-message" id="name-error"></span>
                            </div>
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" required>
                                <span class="error-message" id="email-error"></span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="phone">Phone Number *</label>
                                <input type="tel" id="phone" name="phone" required>
                                <span class="error-message" id="phone-error"></span>
                            </div>
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" id="address" name="address">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h3>Appointment Details</h3>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="service">Service Type *</label>
                                <select id="service" name="service" required>
                                    <option value="consultation" <?php echo ($selectedService == '' || $selectedService == 'consultation') ? 'selected' : ''; ?>>Energy Consultation</option>
                                    <option value="solar" <?php echo ($selectedService == 'solar') ? 'selected' : ''; ?>>Solar Panel Installation</option>
                                    <option value="ev" <?php echo ($selectedService == 'ev') ? 'selected' : ''; ?>>EV Charging Station</option>
                                    <option value="smart" <?php echo ($selectedService == 'smart') ? 'selected' : ''; ?>>Smart Energy System</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="property-type">Property Type *</label>
                                <select id="property-type" name="property_type" required>
                                    <option value="">Select Property Type</option>
                                    <option value="residential">Residential</option>
                                    <option value="commercial">Commercial</option>
                                    <option value="industrial">Industrial</option>
                                </select>
                                <span class="error-message" id="property-error"></span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="preferred-date">Preferred Date *</label>
                                <input type="date" id="preferred-date" name="preferred_date" required min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                                <span class="error-message" id="date-error"></span>
                            </div>
                            <div class="form-group">
                                <label for="preferred-time">Preferred Time *</label>
                                <select id="preferred-time" name="preferred_time" required>
                                    <option value="">Select a Time</option>
                                    <option value="morning">Morning (9AM - 12PM)</option>
                                    <option value="afternoon">Afternoon (1PM - 5PM)</option>
                                    <option value="evening">Evening (6PM - 8PM)</option>
                                </select>
                                <span class="error-message" id="time-error"></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h3>Additional Information</h3>
                        <div class="form-group">
                            <label for="message">Special Requests or Comments</label>
                            <textarea id="message" name="message" rows="4"></textarea>
                        </div>
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" id="terms" name="terms" required>
                                I agree to the <a href="#" class="text-link">terms and conditions</a> *
                            </label>
                            <span class="error-message" id="terms-error"></span>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-lg">Schedule Appointment</button>
                    </div>
                </form>
                <div class="booking-sidebar">
                    <div class="sidebar-card">
                        <h3>Why Choose Rolsa?</h3>
                        <ul class="checkmark-list">
                            <li>Professional, certified technicians</li>
                            <li>Free, no-obligation consultations</li>
                            <li>Customized solutions for your needs</li>
                            <li>Competitive pricing and financing options</li>
                            <li>Industry-leading warranties</li>
                            <li>Ongoing support and maintenance</li>
                        </ul>
                    </div>
                    <div class="sidebar-card">
                        <h3>Have Questions?</h3>
                        <p>Our team is here to help! Contact us directly:</p>
                        <div class="contact-info">
                            <p><strong>Phone:</strong> (555) 123-4567</p>
                            <p><strong>Email:</strong> bookings@rolsatech.com</p>
                            <p><strong>Hours:</strong> Monday-Friday, 9AM-5PM</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Booking Process Section -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">What to <span>Expect</span></h2>
            <div class="process-steps">
                <div class="process-step">
                    <div class="step-number">1</div>
                    <h3>Schedule</h3>
                    <p>Submit your booking request online or by phone. We'll confirm your appointment within 24 hours.</p>
                </div>
                <div class="process-step">
                    <div class="step-number">2</div>
                    <h3>Consultation</h3>
                    <p>Our expert will visit your property to assess your needs and discuss options.</p>
                </div>
                <div class="process-step">
                    <div class="step-number">3</div>
                    <h3>Proposal</h3>
                    <p>You'll receive a detailed proposal with recommended solutions, costs, and projected savings.</p>
                </div>
                <div class="process-step">
                    <div class="step-number">4</div>
                    <h3>Installation</h3>
                    <p>Once approved, we'll schedule and complete your installation with minimal disruption.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- FAQ Section -->
    <section class="section light-green-bg">
        <div class="container">
            <h2 class="section-title">Booking <span>FAQs</span></h2>
            <div class="faq-container">
                <div class="faq-item">
                    <h3 class="faq-question">How long does the booking process take?</h3>
                    <div class="faq-answer">
                        <p>Once you submit your booking request, you'll receive a confirmation email within 24 hours. Consultations can typically be scheduled within 1-2 weeks, while installations may require 2-4 weeks of lead time depending on current demand.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h3 class="faq-question">Is there a fee for consultations?</h3>
                    <div class="faq-answer">
                        <p>No, all initial consultations are completely free and come with no obligation to purchase. We believe in helping you make an informed decision about your energy options.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h3 class="faq-question">What happens if I need to reschedule?</h3>
                    <div class="faq-answer">
                        <p>You can reschedule your appointment up to 24 hours in advance with no penalty. Simply log into your account or contact our customer service team to change your appointment time.</p>
                    </div>
                </div>
                <div class="faq-item">
                    <h3 class="faq-question">Do I need to be present for the consultation or installation?</h3>
                    <div class="faq-answer">
                        <p>We recommend that you be present for the consultation so we can discuss your needs directly. For installations, you or an authorized representative should be present at the beginning and end of the process.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Include footer -->
    <?php include 'includes/footer.php'; ?>
    
    <script src="js/form-validation.js"></script>
    <script>
        // Tab functionality
        document.addEventListener('DOMContentLoaded', function() {
            const tabButtons = document.querySelectorAll('.tab-btn');
            const serviceSelect = document.getElementById('service');
            
            // Tab button click handler
            tabButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Remove active class from all buttons and panels
                    tabButtons.forEach(btn => btn.classList.remove('active'));
                    document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
                    
                    // Add active class to clicked button
                    this.classList.add('active');
                    
                    // Show corresponding panel
                    const tabName = this.getAttribute('data-tab');
                    document.getElementById(tabName + '-panel').classList.add('active');
                    
                    // Update service select and hidden input
                    serviceSelect.value = tabName;
                    document.getElementById('service-type').value = tabName;
                });
            });
            
            // Service select change handler
            serviceSelect.addEventListener('change', function() {
                const selectedService = this.value;
                document.getElementById('service-type').value = selectedService;
                
                // Update tabs
                tabButtons.forEach(btn => {
                    if (btn.getAttribute('data-tab') === selectedService) {
                        btn.click();
                    }
                });
            });
            
            // FAQ accordion
            const faqQuestions = document.querySelectorAll('.faq-question');
            
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const answer = question.nextElementSibling;
                    const isOpen = question.classList.contains('active');
                    
                    // Close all FAQs
                    faqQuestions.forEach(q => {
                        q.classList.remove('active');
                        q.nextElementSibling.style.maxHeight = null;
                    });
                    
                    // If it wasn't open before, open it
                    if (!isOpen) {
                        question.classList.add('active');
                        answer.style.maxHeight = answer.scrollHeight + 'px';
                    }
                });
            });
        });
    </script>
</body>
</html>
