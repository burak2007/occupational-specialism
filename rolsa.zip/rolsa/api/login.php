<?php
// Start session
session_start();

// Include database connection
require_once '../includes/db.php';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect and sanitize input data
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']) ? true : false;
    $return_url = isset($_POST['return_url']) ? $_POST['return_url'] : 'dashboard.php';
    
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['login_error'] = "Invalid email format";
        header("Location: ../login.php?return=" . urlencode($return_url));
        exit;
    }
    
    // Validate password (non-empty)
    if (empty($password)) {
        $_SESSION['login_error'] = "Password is required";
        header("Location: ../login.php?return=" . urlencode($return_url));
        exit;
    }
    
    try {
        // Connect to database
        $conn = connect_db();
        
        // Prepare SQL statement to prevent SQL injection
        $stmt = $conn->prepare("SELECT id, name, email, password, phone, address FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            // User found, verify password
            $user = $result->fetch_assoc();
            
            if (password_verify($password, $user['password'])) {
                // Password is correct, start a new session
                session_regenerate_id(true);
                
                // Store user data in session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_phone'] = $user['phone'];
                $_SESSION['user_address'] = $user['address'];
                
                // If remember me is checked, set cookies (30 days expiration)
                if ($remember) {
                    $token = bin2hex(random_bytes(32)); // Generate a secure token
                    $expires = time() + (86400 * 30); // 30 days
                    
                    // Store token in database
                    $hashed_token = password_hash($token, PASSWORD_DEFAULT);
                    $user_id = $user['id'];
                    
                    $stmt = $conn->prepare("INSERT INTO remember_tokens (user_id, token, expires) VALUES (?, ?, FROM_UNIXTIME(?))");
                    $stmt->bind_param("isi", $user_id, $hashed_token, $expires);
                    $stmt->execute();
                    
                    // Set cookies
                    setcookie("remember_user", $user['id'], $expires, "/", "", true, true);
                    setcookie("remember_token", $token, $expires, "/", "", true, true);
                }
                
                // Log login activity
                $user_id = $user['id'];
                $ip_address = $_SERVER['REMOTE_ADDR'];
                $user_agent = $_SERVER['HTTP_USER_AGENT'];
                
                $stmt = $conn->prepare("INSERT INTO login_activity (user_id, ip_address, user_agent) VALUES (?, ?, ?)");
                $stmt->bind_param("iss", $user_id, $ip_address, $user_agent);
                $stmt->execute();
                
                // Redirect to requested page
                header("Location: ../" . $return_url);
                exit;
            } else {
                // Invalid password
                $_SESSION['login_error'] = "Invalid email or password";
                header("Location: ../login.php?return=" . urlencode($return_url));
                exit;
            }
        } else {
            // User not found
            $_SESSION['login_error'] = "Invalid email or password";
            header("Location: ../login.php?return=" . urlencode($return_url));
            exit;
        }
        
        $stmt->close();
        $conn->close();
    } catch (Exception $e) {
        $_SESSION['login_error'] = "An error occurred. Please try again later.";
        header("Location: ../login.php?return=" . urlencode($return_url));
        exit;
    }
} else {
    // If not a POST request, redirect to login page
    header("Location: ../login.php");
    exit;
}
