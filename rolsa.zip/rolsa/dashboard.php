<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page with return URL
    header("Location: login.php?return=dashboard.php");
    exit;
}

// Page title
$pageTitle = "My Dashboard - Rolsa Technologies";

// Include database connection
require_once 'includes/db.php';

// Get user information
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$user_email = $_SESSION['user_email'];

// Get user's bookings
$bookings = [];
try {
    $conn = connect_db();
    
    $stmt = $conn->prepare("SELECT * FROM bookings WHERE user_id = ? ORDER BY booking_date DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
    
    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    // Handle database error
    $db_error = "Could not retrieve booking information. Please try again later.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Include header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Page Banner -->
    <div class="page-banner" style="background-image: url('api/placeholder.php?width=1200&height=300&text=My Dashboard')">
        <div class="banner-content">
            <h1>My Dashboard</h1>
            <p>Manage your appointments and account</p>
        </div>
    </div>
    
    <!-- Dashboard Section -->
    <section class="section">
        <div class="container">
            <div class="dashboard-container">
                <!-- Sidebar -->
                <div class="dashboard-sidebar">
                    <div class="user-profile">
                        <div class="user-avatar">
                            <?php echo strtoupper(substr($user_name, 0, 1)); ?>
                        </div>
                        <div class="user-info">
                            <h3><?php echo htmlspecialchars($user_name); ?></h3>
                            <p><?php echo htmlspecialchars($user_email); ?></p>
                        </div>
                    </div>
                    <nav class="dashboard-nav">
                        <ul>
                            <li><a href="#bookings" class="active" data-tab="bookings">My Bookings</a></li>
                            <li><a href="#profile" data-tab="profile">Profile Settings</a></li>
                            <li><a href="#notifications" data-tab="notifications">Notifications</a></li>
                            <li><a href="logout.php">Logout</a></li>
                        </ul>
                    </nav>
                </div>
                
                <!-- Main Content -->
                <div class="dashboard-content">
                    <!-- Bookings Tab -->
                    <div class="dashboard-tab active" id="bookings-tab">
                        <div class="tab-header">
                            <h2>My Bookings</h2>
                            <a href="booking.php" class="btn">New Booking</a>
                        </div>
                        
                        <?php if (isset($db_error)): ?>
                            <div class="alert alert-danger">
                                <?php echo $db_error; ?>
                            </div>
                        <?php elseif (empty($bookings)): ?>
                            <div class="empty-state">
                                <div class="empty-icon">📅</div>
                                <h3>No Bookings Yet</h3>
                                <p>You haven't made any bookings or consultation requests.</p>
                                <a href="booking.php" class="btn">Schedule Now</a>
                            </div>
                        <?php else: ?>
                            <div class="booking-filters">
                                <div class="filter-group">
                                    <label for="status-filter">Filter by Status:</label>
                                    <select id="status-filter">
                                        <option value="all">All</option>
                                        <option value="pending">Pending</option>
                                        <option value="confirmed">Confirmed</option>
                                        <option value="completed">Completed</option>
                                        <option value="cancelled">Cancelled</option>
                                    </select>
                                </div>
                                <div class="filter-group">
                                    <label for="service-filter">Filter by Service:</label>
                                    <select id="service-filter">
                                        <option value="all">All</option>
                                        <option value="consultation">Consultation</option>
                                        <option value="solar">Solar Panel Installation</option>
                                        <option value="ev">EV Charging Station</option>
                                        <option value="smart">Smart Energy System</option>
                                    </select>
                                </div>
                                <div class="filter-group">
                                    <label for="search-bookings">Search:</label>
                                    <input type="text" id="search-bookings" placeholder="Search bookings...">
                                </div>
                            </div>
                            
                            <div class="bookings-list">
                                <?php foreach ($bookings as $booking): ?>
                                    <div class="booking-card" 
                                         data-status="<?php echo htmlspecialchars($booking['status']); ?>"
                                         data-service="<?php echo htmlspecialchars($booking['service_type']); ?>">
                                        <div class="booking-header">
                                            <div class="booking-type">
                                                <?php 
                                                    switch($booking['service_type']) {
                                                        case 'consultation':
                                                            echo '🔍 Consultation';
                                                            break;
                                                        case 'solar':
                                                            echo '☀️ Solar Panel Installation';
                                                            break;
                                                        case 'ev':
                                                            echo '🔌 EV Charging Station';
                                                            break;
                                                        case 'smart':
                                                            echo '🏠 Smart Energy System';
                                                            break;
                                                        default:
                                                            echo htmlspecialchars($booking['service_type']);
                                                    }
                                                ?>
                                            </div>
                                            <div class="booking-status <?php echo htmlspecialchars($booking['status']); ?>">
                                                <?php echo ucfirst(htmlspecialchars($booking['status'])); ?>
                                            </div>
                                        </div>
                                        <div class="booking-body">
                                            <div class="booking-info">
                                                <p>
                                                    <strong>Booking Date:</strong> 
                                                    <?php echo date('M d, Y', strtotime($booking['booking_date'])); ?>
                                                </p>
                                                <p>
                                                    <strong>Appointment:</strong> 
                                                    <?php 
                                                        echo date('l, M d, Y', strtotime($booking['preferred_date'])) . ', ';
                                                        switch($booking['preferred_time']) {
                                                            case 'morning':
                                                                echo 'Morning (9AM - 12PM)';
                                                                break;
                                                            case 'afternoon':
                                                                echo 'Afternoon (1PM - 5PM)';
                                                                break;
                                                            case 'evening':
                                                                echo 'Evening (6PM - 8PM)';
                                                                break;
                                                            default:
                                                                echo htmlspecialchars($booking['preferred_time']);
                                                        }
                                                    ?>
                                                </p>
                                                <p>
                                                    <strong>Property Type:</strong> 
                                                    <?php echo ucfirst(htmlspecialchars($booking['property_type'])); ?>
                                                </p>
                                                <?php if (!empty($booking['notes'])): ?>
                                                    <p>
                                                        <strong>Notes:</strong> 
                                                        <?php echo htmlspecialchars($booking['notes']); ?>
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="booking-footer">
                                            <button class="btn-link view-details" data-id="<?php echo $booking['id']; ?>">
                                                View Details
                                            </button>
                                            <?php if ($booking['status'] == 'pending' || $booking['status'] == 'confirmed'): ?>
                                                <button class="btn-link reschedule" data-id="<?php echo $booking['id']; ?>">
                                                    Reschedule
                                                </button>
                                                <button class="btn-link cancel-booking" data-id="<?php echo $booking['id']; ?>">
                                                    Cancel
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Profile Tab -->
                    <div class="dashboard-tab" id="profile-tab">
                        <div class="tab-header">
                            <h2>Profile Settings</h2>
                        </div>
                        <form id="profile-form" class="profile-form" action="api/update-profile.php" method="post">
                            <div class="form-section">
                                <h3>Personal Information</h3>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="profile-name">Full Name</label>
                                        <input type="text" id="profile-name" name="name" value="<?php echo htmlspecialchars($user_name); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="profile-email">Email Address</label>
                                        <input type="email" id="profile-email" name="email" value="<?php echo htmlspecialchars($user_email); ?>" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="profile-phone">Phone Number</label>
                                        <input type="tel" id="profile-phone" name="phone" value="<?php echo isset($user_phone) ? htmlspecialchars($user_phone) : ''; ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="profile-address">Address</label>
                                        <input type="text" id="profile-address" name="address" value="<?php echo isset($user_address) ? htmlspecialchars($user_address) : ''; ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-section">
                                <h3>Change Password</h3>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="current-password">Current Password</label>
                                        <input type="password" id="current-password" name="current_password">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="new-password">New Password</label>
                                        <input type="password" id="new-password" name="new_password">
                                        <span class="help-text">Leave blank if you don't want to change your password</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="confirm-password">Confirm New Password</label>
                                        <input type="password" id="confirm-password" name="confirm_password">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-section">
                                <h3>Communication Preferences</h3>
                                <div class="form-group">
                                    <label class="checkbox-label">
                                        <input type="checkbox" id="email-notifications" name="email_notifications" <?php echo isset($user_preferences['email_notifications']) && $user_preferences['email_notifications'] ? 'checked' : ''; ?>>
                                        Receive email notifications about bookings and promotions
                                    </label>
                                </div>
                                <div class="form-group">
                                    <label class="checkbox-label">
                                        <input type="checkbox" id="sms-notifications" name="sms_notifications" <?php echo isset($user_preferences['sms_notifications']) && $user_preferences['sms_notifications'] ? 'checked' : ''; ?>>
                                        Receive SMS reminders for upcoming appointments
                                    </label>
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="btn">Save Changes</button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Notifications Tab -->
                    <div class="dashboard-tab" id="notifications-tab">
                        <div class="tab-header">
                            <h2>Notifications</h2>
                        </div>
                        <div class="notifications-list">
                            <!-- Sample notifications -->
                            <div class="notification unread">
                                <div class="notification-icon">📅</div>
                                <div class="notification-content">
                                    <h3>Appointment Reminder</h3>
                                    <p>Your consultation is scheduled for tomorrow at 10:00 AM.</p>
                                    <span class="notification-time">2 hours ago</span>
                                </div>
                                <button class="notification-action mark-read" title="Mark as read">✓</button>
                            </div>
                            <div class="notification">
                                <div class="notification-icon">✅</div>
                                <div class="notification-content">
                                    <h3>Booking Confirmed</h3>
                                    <p>Your solar panel installation has been confirmed for May 15, 2025.</p>
                                    <span class="notification-time">2 days ago</span>
                                </div>
                            </div>
                            <div class="notification">
                                <div class="notification-icon">💰</div>
                                <div class="notification-content">
                                    <h3>Special Offer</h3>
                                    <p>Get 10% off on your next smart home energy system installation!</p>
                                    <span class="notification-time">1 week ago</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Booking Details Modal -->
    <div id="booking-details-modal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h3 class="modal-title">Booking Details</h3>
            <div id="booking-details-content">
                <!-- Booking details will be loaded here -->
            </div>
        </div>
    </div>
    
    <!-- Reschedule Modal -->
    <div id="reschedule-modal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h3 class="modal-title">Reschedule Appointment</h3>
            <form id="reschedule-form">
                <input type="hidden" id="reschedule-booking-id" name="booking_id">
                <div class="form-group">
                    <label for="reschedule-date">New Date</label>
                    <input type="date" id="reschedule-date" name="new_date" required min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                </div>
                <div class="form-group">
                    <label for="reschedule-time">New Time</label>
                    <select id="reschedule-time" name="new_time" required>
                        <option value="">Select a Time</option>
                        <option value="morning">Morning (9AM - 12PM)</option>
                        <option value="afternoon">Afternoon (1PM - 5PM)</option>
                        <option value="evening">Evening (6PM - 8PM)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="reschedule-reason">Reason for Rescheduling (Optional)</label>
                    <textarea id="reschedule-reason" name="reason" rows="3"></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary cancel-reschedule">Cancel</button>
                    <button type="submit" class="btn">Reschedule</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Cancel Booking Modal -->
    <div id="cancel-modal" class="modal">
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <h3 class="modal-title">Cancel Booking</h3>
            <form id="cancel-form">
                <input type="hidden" id="cancel-booking-id" name="booking_id">
                <p>Are you sure you want to cancel this booking? This action cannot be undone.</p>
                <div class="form-group">
                    <label for="cancel-reason">Reason for Cancellation (Optional)</label>
                    <textarea id="cancel-reason" name="reason" rows="3"></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary cancel-action">No, Keep Booking</button>
                    <button type="submit" class="btn btn-danger">Yes, Cancel Booking</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Include footer -->
    <?php include 'includes/footer.php'; ?>
    
    <script src="js/dashboard.js"></script>
</body>
</html>
