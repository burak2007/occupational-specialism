<?php
// Start session
session_start();

// Page title
$pageTitle = "Home - Rolsa Technologies";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- Include header -->
    <?php include 'includes/header.php'; ?>

    <!-- Image Carousel -->
    <div class="carousel-container">
        <div class="carousel-slide active" style="background-image: url('img/carousel/slide1.jpg')">
            <div class="carousel-content">
                <h2>Sustainable Energy Solutions</h2>
                <p>Innovative solutions for a greener future</p>
                <a href="#products" class="btn">Explore Products</a>
            </div>
        </div>
        <div class="carousel-slide" style="background-image: url('img/carousel/slide2.jpg')">
            <div class="carousel-content">
                <h2>EV Charging Stations</h2>
                <p>Power your electric vehicle with clean energy</p>
                <a href="booking.php" class="btn">Schedule Installation</a>
            </div>
        </div>
        <div class="carousel-slide" style="background-image: url('img/carousel/slide3.jpg')">
            <div class="carousel-content">
                <h2>Smart Home Energy Management</h2>
                <p>Control and optimize your home's energy usage</p>
                <a href="booking.php" class="btn">Book a Consultation</a>
            </div>
        </div>
        <button class="carousel-prev">←</button>
        <button class="carousel-next">→</button>
        <div class="carousel-nav">
            <div class="carousel-indicator active"></div>
            <div class="carousel-indicator"></div>
            <div class="carousel-indicator"></div>
        </div>
    </div>

    <!-- Products Section -->
    <section id="products" class="section">
        <div class="container">
            <h2 class="section-title">Our <span>Products</span></h2>
            <div class="features">
                <div class="feature-card">
                    <div class="feature-img" style="background-image: url('img/carousel/slide2.jpg')">
                    </div>
                    <div class="feature-content">
                        <h3 class="feature-title">Solar Panel Installation</h3>
                        <p class="feature-text">High-efficiency solar panels that provide clean, renewable energy for
                            your home or business.</p>
                        <a href="booking.php?service=solar" class="btn">Schedule Installation</a>
                    </div>
                </div>
                <div class="feature-card">
                    <div class="feature-img" style="background-image: url('img/carousel/slide1.jpg')">
                    </div>
                    <div class="feature-content">
                        <h3 class="feature-title">EV Charging Stations</h3>
                        <p class="feature-text">Smart charging solutions for electric vehicles at home or for your
                            business.</p>
                        <a href="booking.php?service=ev" class="btn">Schedule Installation</a>
                    </div>
                </div>
                <div class="feature-card">
                    <div class="feature-img" style="background-image: url('img/carousel/slide3.jpg')">
                    </div>
                    <div class="feature-content">
                        <h3 class="feature-title">Smart Energy Management</h3>
                        <p class="feature-text">Intelligent systems that optimize your energy usage and reduce your
                            carbon footprint.</p>
                        <a href="booking.php?service=smart" class="btn">Book a Consultation</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Go Green Teaser -->
    <section class="section green-bg">
        <div class="container">
            <h2 class="section-title light">Why Go <span>Green</span>?</h2>
            <div class="text-center">
                <p class="section-intro">
                    Discover the benefits of sustainable energy for your home, your wallet, and our planet.
                </p>
                <a href="why-go-green.php" class="btn btn-light">Learn More</a>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">Customer <span>Testimonials</span></h2>
            <div class="testimonials">
                <div class="testimonial-card">
                    <p class="testimonial-text">"After installing solar panels from Rolsa Technologies, our energy bills
                        have been reduced by 70%! The installation was professional and quick."</p>
                    <p class="testimonial-author">- Sarah Johnson</p>
                </div>
                <div class="testimonial-card">
                    <p class="testimonial-text">"The EV charging station installed by Rolsa has made owning an electric
                        vehicle so convenient. I love being able to charge at home!"</p>
                    <p class="testimonial-author">- Michael Chen</p>
                </div>
                <div class="testimonial-card">
                    <p class="testimonial-text">"Their smart home energy management system has completely transformed
                        how we use energy. We can monitor and control usage from our phones!"</p>
                    <p class="testimonial-author">- Emma Rodriguez</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Booking CTA -->
    <section class="section cta-section">
        <div class="container">
            <h2 class="section-title light">Ready to Make the Switch?</h2>
            <div class="text-center">
                <p class="cta-text">
                    Schedule a consultation or installation today and take the first step towards sustainable energy.
                </p>
                <a href="booking.php" class="btn btn-light">Book Now</a>
            </div>
        </div>
    </section>

    <!-- Include footer -->
    <?php include 'includes/footer.php'; ?>

    <!-- JavaScript -->
    <script src="js/carousel.js"></script>
</body>

</html>