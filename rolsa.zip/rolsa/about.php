<?php
// Start session
session_start();

// Page title
$pageTitle = "About Us - Rolsa Technologies";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Include header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Page Banner -->
    <div class="page-banner" style="background-image: url('api/placeholder.php?width=1200&height=300&text=About Rolsa Technologies')">
        <div class="banner-content">
            <h1>About Us</h1>
            <p>Learn more about our mission and vision</p>
        </div>
    </div>
    
    <!-- About Section -->
    <section class="section">
        <div class="container">
            <div class="about-grid">
                <div class="about-content">
                    <h2 class="section-title">Our <span>Story</span></h2>
                    <p>
                        Founded in 2015, Rolsa Technologies began with a simple mission: to make green energy accessible 
                        and affordable for everyone. What started as a small team of passionate engineers has grown into 
                        a leading provider of sustainable energy solutions in the region.
                    </p>
                    <p>
                        We believe that the transition to renewable energy is not just an environmental necessity, but 
                        also an economic opportunity. Our team of experts is dedicated to helping homes and businesses 
                        reduce their carbon footprint while also reducing their energy costs.
                    </p>
                    <p>
                        At Rolsa Technologies, we're not just selling products – we're building a sustainable future.
                    </p>
                </div>
                <div class="about-image">
                    <img src="api/placeholder.php?width=500&height=400&text=Rolsa Team" alt="Rolsa Team">
                </div>
            </div>
        </div>
    </section>
    
    <!-- Our Mission Section -->
    <section class="section green-bg">
        <div class="container">
            <h2 class="section-title light">Our <span>Mission</span></h2>
            <div class="mission-values">
                <div class="mission-item">
                    <div class="mission-icon">🌱</div>
                    <h3>Sustainability</h3>
                    <p>
                        We are committed to promoting sustainable energy solutions that reduce environmental impact 
                        and create a healthier planet for future generations.
                    </p>
                </div>
                <div class="mission-item">
                    <div class="mission-icon">💡</div>
                    <h3>Innovation</h3>
                    <p>
                        We continuously research and integrate cutting-edge technologies to provide the most efficient 
                        and effective green energy solutions.
                    </p>
                </div>
                <div class="mission-item">
                    <div class="mission-icon">🤝</div>
                    <h3>Accessibility</h3>
                    <p>
                        We strive to make sustainable energy solutions accessible and affordable for all homes and 
                        businesses, regardless of size or budget.
                    </p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Our Team Section -->
    <section class="section">
        <div class="container">
            <h2 class="section-title">Our <span>Team</span></h2>
            <div class="team-grid">
                <div class="team-member">
                    <div class="team-photo" style="background-image: url('api/placeholder.php?width=300&height=300&text=CEO')"></div>
                    <h3 class="team-name">David Chen</h3>
                    <p class="team-role">CEO & Founder</p>
                    <p class="team-bio">
                        With over 15 years of experience in renewable energy, David founded Rolsa Technologies 
                        with a vision of making green energy accessible to everyone.
                    </p>
                </div>
                <div class="team-member">
                    <div class="team-photo" style="background-image: url('api/placeholder.php?width=300&height=300&text=CTO')"></div>
                    <h3 class="team-name">Sarah Martinez</h3>
                    <p class="team-role">Chief Technology Officer</p>
                    <p class="team-bio">
                        Sarah leads our technical innovation, bringing her expertise in electrical engineering 
                        and smart grid technology to all our solutions.
                    </p>
                </div>
                <div class="team-member">
                    <div class="team-photo" style="background-image: url('api/placeholder.php?width=300&height=300&text=Operations')"></div>
                    <h3 class="team-name">Michael Johnson</h3>
                    <p class="team-role">Operations Director</p>
                    <p class="team-bio">
                        Michael ensures that all our installations and services are delivered with the highest 
                        quality and efficiency, exceeding customer expectations.
                    </p>
                </div>
                <div class="team-member">
                    <div class="team-photo" style="background-image: url('api/placeholder.php?width=300&height=300&text=Customer Relations')"></div>
                    <h3 class="team-name">Emily Wong</h3>
                    <p class="team-role">Customer Relations Manager</p>
                    <p class="team-bio">
                        Emily is dedicated to providing exceptional customer service, ensuring that each client 
                        receives personalized attention throughout their green energy journey.
                    </p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- CTA Section -->
    <section class="section cta-section">
        <div class="container">
            <h2 class="section-title light">Join Our <span>Green Revolution</span></h2>
            <div class="text-center">
                <p class="cta-text">
                    Ready to transform your energy usage and reduce your carbon footprint?
                </p>
                <a href="booking.php" class="btn btn-light">Schedule a Consultation</a>
            </div>
        </div>
    </section>
    
    <!-- Include footer -->
    <?php include 'includes/footer.php'; ?>
</body>
</html>
